import clsx from "clsx"
import { ALL_DAYS, type DayCode } from "../lib/data"

export function DayPicker({
  selected,
  onChange,
}: {
  selected: DayCode[]
  onChange: (days: DayCode[]) => void
}) {
  function toggle(day: DayCode) {
    if (selected.includes(day)) {
      onChange(selected.filter((d) => d !== day))
    } else {
      onChange([...ALL_DAYS].filter((d) => selected.includes(d) || d === day))
    }
  }

  return (
    <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
      {ALL_DAYS.map((day) => {
        const active = selected.includes(day)
        return (
          <button
            key={day}
            type="button"
            onClick={() => toggle(day)}
            aria-pressed={active}
            className={clsx(
              "tap-scale flex h-11 flex-col items-center justify-center rounded-xl border text-xs font-semibold transition-colors sm:h-12 sm:text-sm",
              active
                ? "border-brand bg-brand text-white shadow-[0_8px_20px_-8px_rgba(57,70,234,0.7)]"
                : "border-border bg-surface-raised text-ink-muted hover:border-border-strong hover:text-ink",
            )}
          >
            {day.slice(0, 2)}
          </button>
        )
      })}
    </div>
  )
}
